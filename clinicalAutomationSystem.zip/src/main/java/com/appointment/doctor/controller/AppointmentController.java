package com.appointment.doctor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.service.AppointmentService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;
	
	@PostMapping("/book/appointment")
	public ResponseEntity<Appointment> bookAppointment(@RequestBody Appointment appointment){
		return appointmentService.bookAppointment(appointment);
	}
	
	@GetMapping("/appointments/doctor/{id}")
	public ResponseEntity<List<Appointment>> getDoctorAppointments(@PathVariable int id,@RequestParam(required = false,defaultValue = "ALL")String status){
		return appointmentService.getDoctorsAppointment(id,status);
	}
	
	@PutMapping("/appointment/{id}/{status}")
	public ResponseEntity<?> updateStatus(@PathVariable int id,@PathVariable String status){
		return appointmentService.updateStatus(id,status);
	}
	@GetMapping("/appointment/{id}")
	public ResponseEntity<?> get(@PathVariable int id){
		return appointmentService.get(id);
	}
	
	@GetMapping("/appointments/patient/{id}")
	public ResponseEntity<List<Appointment>> getPatientAppointments(@PathVariable int id,@RequestParam(required = false,defaultValue = "ALL")String status){
		return appointmentService.getPatientAppointments(id,status);
	}
	
	@GetMapping("/appointments/patient/name/{name}")
	public ResponseEntity<List<Appointment>> getPatientAppointmentsByName(@PathVariable String name){
		return appointmentService.getPatientAppointmentsByName(name);
	}
	@GetMapping("all/appointments")
	public ResponseEntity<List<Appointment>> getAllAppointment(){
		return appointmentService.getAllAppointment();
	}
	
}
