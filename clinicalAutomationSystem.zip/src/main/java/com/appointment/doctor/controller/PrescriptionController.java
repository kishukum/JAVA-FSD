package com.appointment.doctor.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.appointment.doctor.entity.Prescription;
import com.appointment.doctor.service.PrescriptionService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class PrescriptionController {
	
	@Autowired
	private PrescriptionService prescriptionService;
	
	
	@PostMapping("/prescription")
	public ResponseEntity<?> addPrescription(@RequestBody Prescription prescription){
		return prescriptionService.save(prescription);
	}
	
	@GetMapping("/prescription/patient/{id}")
	public ResponseEntity<?> getPatientPrescription(@PathVariable int id){
		return prescriptionService.getPatientPrescription(id);
	}
	
	@GetMapping("/prescription/{id}")
	public ResponseEntity<?> getPrescription(@PathVariable int id){
		return prescriptionService.getPrescription(id);
	}

}
