package com.appointment.doctor.dto;

public class ResetPassword {

	
	public String email;
	public String newPassword;
	public String oldPassword;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
	@Override
	public String toString() {
		return "ResetPassword [email=" + email + ", newPassword=" + newPassword + ", oldPassword=" + oldPassword + "]";
	}
	public ResetPassword(String email, String newPassword, String oldPassword) {
		super();
		this.email = email;
		this.newPassword = newPassword;
		this.oldPassword = oldPassword;
	}
	public ResetPassword() {
		super();
	}
	
	

}
