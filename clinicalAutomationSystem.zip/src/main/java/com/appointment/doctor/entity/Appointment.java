package com.appointment.doctor.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.fasterxml.jackson.annotation.JsonFormat;
@Entity
@Table(name = "appointment")
public class Appointment {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@NotFound(action = NotFoundAction.IGNORE)
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "doctor_id")
	private Doctor doctor;
	
	@OneToOne(cascade = {CascadeType.MERGE}, fetch = FetchType.EAGER)
	@JoinColumn(name = "patient_id")
	private Patient patient;
	
	@Column(name = "status")
	private String status;
	
    @JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss")
	@Column(name = "appointment_at")
	private LocalDateTime appointmentAt;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getAppointmentAt() {
		return appointmentAt;
	}

	public void setAppointmentAt(LocalDateTime appointmentAt) {
		this.appointmentAt = appointmentAt;
	}

	@Override
	public String toString() {
		return "Appointment [id=" + id + ", doctor=" + doctor + ", patient=" + patient + ", status=" + status
				+ ", appointmentAt=" + appointmentAt + "]";
	}

	public Appointment(int id, Doctor doctor, Patient patient, String status, LocalDateTime appointmentAt) {
		super();
		this.id = id;
		this.doctor = doctor;
		this.patient = patient;
		this.status = status;
		this.appointmentAt = appointmentAt;
	}

	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
