package com.appointment.doctor.entity;

import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "prescription")
public class Prescription {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@OneToOne(cascade = {CascadeType.MERGE}, fetch = FetchType.EAGER)
	@JoinColumn(name = "appointment_id")
	private Appointment appointment;
	@OneToMany(cascade = {CascadeType.MERGE}, fetch = FetchType.EAGER)
	@JoinColumn(name = "tablet_id")
	private List<Tablet> tablets;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Appointment getAppointment() {
		return appointment;
	}
	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}
	public List<Tablet> getTablets() {
		return tablets;
	}
	public void setTablets(List<Tablet> tablets) {
		this.tablets = tablets;
	}
	public Prescription(int id, Appointment appointment, List<Tablet> tablets) {
		super();
		this.id = id;
		this.appointment = appointment;
		this.tablets = tablets;
	}
	public Prescription() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Prescription [id=" + id + ", appointment=" + appointment + ", tablets=" + tablets + "]";
	}

	
	
}
