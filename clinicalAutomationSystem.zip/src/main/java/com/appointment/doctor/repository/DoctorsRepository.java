package com.appointment.doctor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.appointment.doctor.entity.Doctor;


@Repository
public interface DoctorsRepository extends JpaRepository<Doctor, Integer> {

	List<Doctor> findBySpecialization(String specialization);

	boolean existsByEmailAndPassword(String name, String password);

	Doctor findByEmail(String name);

	boolean existsByEmail(String name);
	
	Doctor findByEmailAndPassword(String name, String password);

	boolean existsByNameAndPassword(String email, String password);
}
