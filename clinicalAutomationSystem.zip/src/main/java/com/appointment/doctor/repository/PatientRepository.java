package com.appointment.doctor.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.appointment.doctor.entity.Patient;
@Repository
public interface PatientRepository extends JpaRepository<Patient, Integer>{

	Patient findByEmail(String email);

	boolean existsByEmail(String email);
	
	Patient findByEmailAndPassword(String email, String password);

	boolean existsByEmailAndPassword(String email, String password);

}
