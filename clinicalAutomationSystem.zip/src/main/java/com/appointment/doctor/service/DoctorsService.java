package com.appointment.doctor.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.appointment.doctor.entity.Doctor;

public interface DoctorsService {

	ResponseEntity<?> saveDoctor(Doctor doctor);

	ResponseEntity<List<Doctor>> getAllDoctors(String specialization);

}
