package com.appointment.doctor.service;

import org.springframework.http.ResponseEntity;

import com.appointment.doctor.dto.LogIn;
import com.appointment.doctor.dto.ResetPassword;

public interface LogInService {

	ResponseEntity<?> logIn(LogIn login);

	ResponseEntity<String> reset(ResetPassword reset);

}
