package com.appointment.doctor.service;

import org.springframework.http.ResponseEntity;

import com.appointment.doctor.entity.Patient;

public interface PatientService {

	ResponseEntity<?> savePatient(Patient patient);

}
