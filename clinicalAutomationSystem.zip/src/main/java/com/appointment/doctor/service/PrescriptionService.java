package com.appointment.doctor.service;

import org.springframework.http.ResponseEntity;

import com.appointment.doctor.entity.Prescription;

public interface PrescriptionService {

	ResponseEntity<?> save(Prescription prescription);

	ResponseEntity<?> getPatientPrescription(int id);

	ResponseEntity<?> getPrescription(int id);

}
