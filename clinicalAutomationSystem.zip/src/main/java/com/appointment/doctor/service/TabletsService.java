package com.appointment.doctor.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.appointment.doctor.entity.Tablet;

public interface TabletsService {

	ResponseEntity<?> save(Tablet tablet);

	ResponseEntity<?> update(Tablet tablet);

	ResponseEntity<List<Tablet>> getAll();

	ResponseEntity<?> getById(int id);

	ResponseEntity<String> deleteById(int id);

	ResponseEntity<?> getByName(String name);

}
