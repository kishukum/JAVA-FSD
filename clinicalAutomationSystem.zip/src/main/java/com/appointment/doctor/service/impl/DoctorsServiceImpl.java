package com.appointment.doctor.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.appointment.doctor.entity.Doctor;
import com.appointment.doctor.repository.DoctorsRepository;
import com.appointment.doctor.service.DoctorsService;
@Service
public class DoctorsServiceImpl  implements DoctorsService{

	@Autowired
	private DoctorsRepository  doctorsRepository;
	
	@Override
	public ResponseEntity<?> saveDoctor(Doctor doctor) {
		if(doctorsRepository.existsByEmail(doctor.getEmail())) {
			return new ResponseEntity<String>("Doctor already exist",HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Doctor>(doctorsRepository.save(doctor),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<Doctor>> getAllDoctors(String specialization) {
		if(specialization==null || specialization.isBlank()) {
			return new ResponseEntity<List<Doctor>>(doctorsRepository.findAll(), HttpStatus.OK);
		}
		return new ResponseEntity<List<Doctor>>(doctorsRepository.findBySpecialization(specialization), HttpStatus.OK);
	}

}
