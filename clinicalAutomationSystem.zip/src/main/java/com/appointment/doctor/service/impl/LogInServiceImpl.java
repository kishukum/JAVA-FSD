package com.appointment.doctor.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.appointment.doctor.dto.LogIn;
import com.appointment.doctor.dto.ResetPassword;
import com.appointment.doctor.entity.Doctor;
import com.appointment.doctor.entity.Patient;
import com.appointment.doctor.repository.DoctorsRepository;
import com.appointment.doctor.repository.PatientRepository;
import com.appointment.doctor.service.LogInService;
@Service
public class LogInServiceImpl implements LogInService {
	
	
	@Autowired
	private PatientRepository patientRepository;
	
	@Autowired
	private DoctorsRepository doctorsRepository;

	@Override
	public ResponseEntity<?> logIn(LogIn login) {
		if(patientRepository.existsByEmailAndPassword(login.getEmail(),login.getPassword())) {
			return new ResponseEntity<Patient>(patientRepository.findByEmailAndPassword(login.getEmail(),login.getPassword()),HttpStatus.OK);
		}else if (doctorsRepository.existsByNameAndPassword(login.getEmail(),login.getPassword())) {
			return new ResponseEntity<Doctor>(doctorsRepository.findByEmailAndPassword(login.getEmail(),login.getPassword()),HttpStatus.OK);
		}
		return new ResponseEntity<String>("User not found",HttpStatus.BAD_REQUEST);
	}

	@Override
	public ResponseEntity<String> reset(ResetPassword reset) {
		if(patientRepository.existsByEmailAndPassword(reset.getEmail(),reset.getOldPassword())) {
			Patient p=patientRepository.findByEmail(reset.getEmail());
			p.setPassword(reset.getNewPassword());
			patientRepository.save(p);
			return new ResponseEntity<String>("Patient password changed",HttpStatus.OK);
		}else if (doctorsRepository.existsByNameAndPassword(reset.getEmail(),reset.getOldPassword())) {
			Doctor d=doctorsRepository.findByEmail(reset.getEmail());
			d.setPassword(reset.getNewPassword());
			doctorsRepository.save(d);
			return new ResponseEntity<String>("Patient password changed",HttpStatus.OK);
		}
		return new ResponseEntity<String>("User not found",HttpStatus.BAD_REQUEST);
	}
	

}
