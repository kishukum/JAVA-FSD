package com.appointment.doctor.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.appointment.doctor.entity.Tablet;
import com.appointment.doctor.repository.TabletRepository;
import com.appointment.doctor.service.TabletsService;

@Service
public class TabletsServiceImpl implements TabletsService{
	
	@Autowired
	private TabletRepository tabletRepository;

	@Override
	public ResponseEntity<?> save(Tablet tablet) {
		if(tabletRepository.existsByName(tablet.getName())) {
			return new ResponseEntity<String>("Tablet Already exist",HttpStatus.BAD_REQUEST);
		}else {
			return new ResponseEntity<Tablet> (tabletRepository.save(tablet),HttpStatus.OK);
		}
	}

	@Override
	public ResponseEntity<?> update(Tablet tablet) {
		if(tabletRepository.existsByName(tablet.getName())) {
			return new ResponseEntity<Tablet> (tabletRepository.save(tablet),HttpStatus.OK);
		}else {
			return new ResponseEntity<String>("Tablet Not exist",HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	public ResponseEntity<List<Tablet>> getAll() {
		return new ResponseEntity<List<Tablet>> (tabletRepository.findAll(),HttpStatus.OK);

	}

	@Override
	public ResponseEntity<?> getById(int id) {
		Optional<Tablet> t= tabletRepository.findById(id);
		if(t.isEmpty()) {
			return new ResponseEntity<String>("Tablet Not exist",HttpStatus.BAD_REQUEST);
		}else {
			return new ResponseEntity<Tablet> (t.get(),HttpStatus.OK);
		}
	}

	@Override
	public ResponseEntity<String> deleteById(int id) {
		tabletRepository.deleteById(id);
		return new ResponseEntity<String> ("Tablet deleted successfully",HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getByName(String name) {
		return new ResponseEntity<Tablet> (tabletRepository.findByName(name),HttpStatus.OK);

	}

}
