package com.appointment.doctor.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.entity.Doctor;
import com.appointment.doctor.service.AppointmentService;
import com.appointment.doctor.service.DoctorsService;
import com.fasterxml.jackson.databind.ObjectMapper;
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {DoctorsController.class })
@ExtendWith(SpringExtension.class)

public class DoctorsControllerTest {
	@Autowired
    private DoctorsController doctorsController;

	@MockBean
	private DoctorsService doctorsService;
	@Test
	public void  testsave()  throws Exception  {
		Doctor doctor=new Doctor();	
		doctorsController.save(doctor);
			 }
	@Test
	public void  testgetAll()  throws Exception  {
		String specialization="";
		doctorsController.getAll(specialization);
			 }}
	
