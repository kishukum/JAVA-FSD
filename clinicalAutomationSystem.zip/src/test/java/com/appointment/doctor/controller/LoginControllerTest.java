package com.appointment.doctor.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.appointment.doctor.dto.LogIn;
import com.appointment.doctor.dto.ResetPassword;
import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.entity.Doctor;
import com.appointment.doctor.service.AppointmentService;
import com.appointment.doctor.service.DoctorsService;
import com.appointment.doctor.service.LogInService;
import com.fasterxml.jackson.databind.ObjectMapper;
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {LoginController.class })
@ExtendWith(SpringExtension.class)

public class LoginControllerTest {
	@Autowired
    private LoginController loginController;

	@MockBean
	private LogInService logIInService;
	@Test
	public void  testlogIn()  throws Exception  {
		LogIn login=new LogIn();		loginController.logIn(login);
			 }
	@Test
	public void  testreset()  throws Exception  {
		ResetPassword reset=new ResetPassword();		loginController.reset(reset);
			 }}
	
