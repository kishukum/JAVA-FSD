package com.appointment.doctor.dto;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.service.AppointmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {LogIn.class })
@ExtendWith(SpringExtension.class)

public class LogInTest {
	@Autowired
    private LogIn logIn;

	@MockBean
	private AppointmentService appointmentService;
	@Test
	public void  testsetEmail()  throws Exception  {
		String email="tewe";	
		logIn.setEmail(email);
			 }
	@Test
	public void  testgetPassword()  throws Exception  {
		String email="tewe";	
		logIn.getPassword();
			 }
	@Test
	public void  testsetPassword()  throws Exception  {
		String email="tewe";
		logIn.setPassword(email);
			 }
	@Test
	public void  testtoString()  throws Exception  {
		String email="tewe";
		logIn.toString();
			 }
	
	}
