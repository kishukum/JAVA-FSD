package com.appointment.doctor.entity;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.service.AppointmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {Doctor.class })
@ExtendWith(SpringExtension.class)

public class DoctorTest {
	@Autowired
    private Doctor doctor;

	@MockBean
	private AppointmentService appointmentService;
	@Test
	public void  testgetId()  throws Exception  {
		doctor.getId();
			 }
	@Test
	public void  testsetId()  throws Exception  {
		doctor.setId(0);
			 }

	@Test
	public void  testgetName()  throws Exception  {
		doctor.getName();
			 }

	@Test
	public void  testsetName()  throws Exception  {
String str="";	
doctor.setName(str);
			 }

	@Test
	public void  testgetSpecialization()  throws Exception  {
		doctor.getSpecialization();
			 }

	@Test
	public void  testsetSpecialization()  throws Exception  {
		String specialization="";		
		doctor.setSpecialization(specialization);
			 }

	@Test
	public void  testgetEmail()  throws Exception  {
		doctor.getEmail();
			 }

	@Test
	public void  testsetEmail()  throws Exception  {
		String status="Y";		
		doctor.setEmail(status);
			 }

	@Test
	public void  testgetVisitations()  throws Exception  {
		doctor.getVisitations();
			 }
	@Test
	public void  testsetVisitations()  throws Exception  {
		String visitations="";	
		doctor.setVisitations(visitations);
			 }
	@Test
	public void  testgetPassword()  throws Exception  {
		String visitations="";		
		doctor.getPassword();
			 }
	@Test
	public void  testsetPassword()  throws Exception  {
					String visitations="";		doctor.setPassword(visitations);
						 
			 }
	@Test
	public void  testgetContactNumber()  throws Exception  {
								String visitations="";	
								doctor.getContactNumber();
									 }
	@Test
	public void  testgetAge()  throws Exception  {
								doctor.getAge();
									 }

	@Test
	public void  testsetAge()  throws Exception  {
		int age=3;
		doctor.setAge(age);
									 }

	@Test
	public void  testgetGender()  throws Exception  {
								String visitations="";	
								doctor.getGender();
									 }

	@Test
	public void  testsetGender()  throws Exception  {
								String Gender="";	
								doctor.setGender(Gender);
									 }

	@Test
    public void testToString() {
        Doctor doctor = new Doctor();
        Patient patient = new Patient();
        String status = "PENDING";
        LocalDateTime appointmentAt = LocalDateTime.now();

        Appointment appointment = new Appointment(1, doctor, patient, status, appointmentAt);
        String expectedToString = "Appointment [id=1, doctor=" + doctor + ", patient=" + patient + ", status=" + status
            + ", appointmentAt=" + appointmentAt + "]";

        assertEquals(expectedToString, appointment.toString());
    }
	 @Test
	    public void testDoctorConstructor() {
	        int id = 1;
	        String name = "Dr. John Doe";
	        String specialization = "Cardiology";
	        String email = "john.doe@example.com";
	        String visitations = "Monday, Wednesday, Friday";
	        String password = "password123";
	        String contactNumber = "+1234567890";
	        int age = 40;
	        String gender = "Male";

	        Doctor doctor = new Doctor(id, name, specialization, email, visitations, password, contactNumber, age, gender);

	        assertEquals(id, doctor.getId());
	        assertEquals(name, doctor.getName());
	        assertEquals(specialization, doctor.getSpecialization());
	        assertEquals(email, doctor.getEmail());
	        assertEquals(visitations, doctor.getVisitations());
	        assertEquals(password, doctor.getPassword());
	        assertEquals(contactNumber, doctor.getContactNumber());
	        assertEquals(age, doctor.getAge());
	        assertEquals(gender, doctor.getGender());
	    }
			 }
