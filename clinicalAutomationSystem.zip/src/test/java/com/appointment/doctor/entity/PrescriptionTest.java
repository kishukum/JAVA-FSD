package com.appointment.doctor.entity;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.service.AppointmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {Prescription.class })
@ExtendWith(SpringExtension.class)

public class PrescriptionTest {
	@Autowired
    private  Prescription  prescription;

	@MockBean
	private AppointmentService appointmentService;
	@Test
	public void  testgetId()  throws Exception  {
		prescription.getId();
			 }
	@Test
	public void  testsetId()  throws Exception  {
		prescription.setId(0);
			 }

	@Test
	public void  testgetAppointment()  throws Exception  {
		prescription.getAppointment();
			 }

	@Test
	public void  testsetAppointment()  throws Exception  {
		Appointment appointment=new Appointment ();
		prescription.setAppointment(appointment);
			 }

	@Test
	public void  testgetTablets()  throws Exception  {
		prescription.getTablets();
			 }

	@Test
	public void  testsetTablets()  throws Exception  {
		List<Tablet> tablets=new ArrayList<>();
		prescription.setTablets(tablets);
			 }
	  @Test
	    public void testPrescriptionConstructor() {
	        int id = 1;
	        double innn=988;
	        Appointment appointment = new Appointment();
	        List<Tablet> tablets = new ArrayList<>();
	        tablets.add(new Tablet(id, "Tablet1", id, innn));
	        tablets.add(new Tablet(id, "Tablet1", id, innn));

	        Prescription prescription = new Prescription(id, appointment, tablets);

	        assertEquals(id, prescription.getId());
	        assertEquals(appointment, prescription.getAppointment());
	        assertEquals(tablets, prescription.getTablets());
	    }
	  @Test
	    public void testToString() {
	        Appointment appointment = new Appointment();
	        List<Tablet> tablets = new ArrayList<>();
	        double innn=988;
int id=8;
	        tablets.add(new Tablet(id, "Tablet1", id, innn));
	        tablets.add(new Tablet(id, "Tablet1", id, innn));

	        Prescription prescription = new Prescription(1, appointment, tablets);
	        String expectedToString = "Prescription [id=1, appointment=" + appointment + ", tablets=" + tablets + "]";
	        
	        assertEquals(expectedToString, prescription.toString());
	    }

				 }
